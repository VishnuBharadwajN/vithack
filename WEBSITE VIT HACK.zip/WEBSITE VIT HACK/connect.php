<?php
$drHost ="localhost";
$drUser ="root";
$drPass = "";
$drDb = "patient_info";
try{
	//$conn = mysqli_connect($drHost,$drUser,$drPass,$drDb);
	$drConnect = new PDO("mysql:host=$drHost;dbname=$drDb",$drUser,$drPass);
	$drConnect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}
catch(PDOException $drError){
	echo "Failed To Connect ".$drError->getMessage();
}
if(isset($_POST['Submit'])){
	$patientid= $_POST['patient_id'];
	$reportedon = $_POST['Reported_on'];
	$Ageestimated = $_POST['Age_estimate'];
	$gender = $_POST['Gender'];
	$state = $_POST['State'];
	$status = $_POST['Status'];

	$drSql ="INSERT INTO patient_info(patientId ,reportedOn,ageEstimate,gender,state,status) VALUES('$patientid','$reportedon','$Ageestimated','$gender','$state','$status')";
	 $drConnect->exec($drSql);
}

?>

<!--Main wrapper-->
<link rel ="stylesheet"
type = "text/css"
href="4th.css"/>
<script src="4th.js"></script>

<script src=
    "https://smtpjs.com/v3/smtp.js">
  </script>

  <script type="text/javascript">
    function sendEmail() {
      Email.send({
        Host: "smtp.gmail.com",
        Username: "vbshwebsite@gmail.com",
        Password: "vbsh1352002",
        To: 'receiver@email_address.com',
        From: "vbshwebsite@gmail.com",
        Subject: "Sending Email using javascript",
        Body: "graph is ",
      })
        .then(function (message) {
          alert("mail sent successfully")
        });
    }
  </script>


<div class="wrapper">
    <h1>Registration form</h1>

    <!--form container-->
    <div class="form-container">
    <form method="post">
        <!--flexbox and it's items-->
        <div class="flex">
            <div class="flex-item">
            <!--full name field-->
                <div class="field-container">
                    <label for="Patient id">Patient id: <span class="required">*</span></label>
                    <input type="number" name="patient_id"   pattern="[0-9]{10}" placeholder="patient id" required="required" />
                    <span class="error-messg"></span>
                </div>

             <!--email field-->
                <div class="field-container">
                    <label for="Reported_on">Reported on <span class="required">*</span></label>
                    <input type="string " name="Reported_on" placeholder="Reported date" required="required" />
                    <span class="error-messg"></span>
                </div>

             <!--confirm email field-->
                <div class="field-container">
                    <label for="age estimate">Age estimate <span class="required">*</span></label>
                    <input type="Age estimate" name="Age_estimate" id="Age estimate" placeholder="Age estimate" required="required" />
                    <span class="error-messg"></span>
                </div>

            </div>
            <div class="flex-item">
                <!--contact no field-->
                <div class="field-container">
                    <label for="gender">Gender: <span class="required">*</span></label>
                    <input type="text" name="Gender" pattern="^([a-zA-Z]{2,} ?)+$" id="Gender" placeholder="Gender" required="required" />
                    <span class="error-messg"></span>
                </div>

                <!--state-->
                <div class="field-container">
                    <label for="State">State: <span class="required">*</span></label>
                    <input type="State" name="State" id="State" placeholder="Your State" required="required" />
                    <span class="error-messg"></span>
                </div>

                <!--status-->
              <div class="field-container">
                    <label for="Status">Status: <span class="required">*</span></label>
                    <input type="Status" name="Status" id="Status" placeholder="Your Status" required="required" />
                    <span class="error-messg"></span>
                </div>

        <!--Submit button-->
        <div class="center"><input type="submit" name="Submit" value="Submit"></div>
    </form>

		<form method="post">
			<label for="gender">Gender</label>
		    <input type="button" value="Send Email"
		        onclick="sendEmail()" />
		  </form>

    </div>

</div>
